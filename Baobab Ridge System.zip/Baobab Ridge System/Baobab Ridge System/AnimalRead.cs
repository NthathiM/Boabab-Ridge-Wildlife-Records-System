﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Baobab_Ridge_System
{
    internal class AnimalRead
    {
        public string filepath = @"C:\Users\niena\source\repos\PRG 282 Project\Baobab Ridge System\Baobab Ridge System\animals.txt";

        public List<string> readAnimal()
        {
            List<string> listOfAnimals = new List<string>();
            listOfAnimals = File.ReadAllLines(filepath).ToList();
            return listOfAnimals;
        }
    }
}
